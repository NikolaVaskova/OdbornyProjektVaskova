package org.example;

public enum Names {
    PERSON, DEVICE
}
