package org.example;

public enum DeviceOperations {
    CHANGED_PC, NEW_PC, SCARPED_PC, STORED_PC
}
